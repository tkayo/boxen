require 'spec_helper'

describe 'brewcask' do
  let(:facts) { default_test_facts }
end
